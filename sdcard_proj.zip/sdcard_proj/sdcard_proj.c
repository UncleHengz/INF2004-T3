#include <stdio.h>
#include "pico/stdlib.h"
#include "sd_card.h"
#include "ff.h"
#include "diskio.h"

void list_files(const char *path) {
    FRESULT fr;
    DIR dir;
    static FILINFO fno;

    fr = f_opendir(&dir, path); // Open directory
    if (fr != FR_OK) {
        printf("ERROR: Could not open directory (%d)\r\n", fr);
        return;
    }

    while (true) {
        fr = f_readdir(&dir, &fno); // Read a directory item
        if (fr != FR_OK || fno.fname[0] == 0) {
            break; // Break on error or end of directory
        }
        if (fno.fattrib & AM_DIR) { // Check if it's a directory
            printf("Directory: %s\r\n", fno.fname);
        } else {
            printf("File: %s\r\n", fno.fname);
        }
    }
}

void read_file(const char *path) {
    FIL fil;
    FRESULT fr;
    char buf[100];

    fr = f_open(&fil, path, FA_READ);
    if (fr != FR_OK) {
        printf("ERROR: Could not open file %s (%d)\r\n", path, fr);
        return;
    }

    printf("Reading from file '%s':\r\n", path);
    printf("---\r\n");
    while (f_gets(buf, sizeof(buf), &fil)) {
        printf(buf);
    }
    printf("\r\n---\r\n");

    fr = f_close(&fil);
    if (fr != FR_OK) {
        printf("ERROR: Could not close file %s (%d)\r\n", path, fr);
    }
}

void list_and_read_files(const char *path) {
    FRESULT fr;
    DIR dir;
    static FILINFO fno;
    char full_path[100]; // Buffer to store the full path of the file

    fr = f_opendir(&dir, path);
    if (fr != FR_OK) {
        printf("ERROR: Could not open directory (%d)\r\n", fr);
        return;
    }

    while (true) {
        fr = f_readdir(&dir, &fno);
        if (fr != FR_OK || fno.fname[0] == 0) break;
        
        if (fno.fattrib & AM_DIR) {
            printf("Directory: %s\r\n", fno.fname);
        } else {
            printf("File: %s\r\n", fno.fname);
            snprintf(full_path, sizeof(full_path), "%s/%s", path, fno.fname); // Create the full path
            read_file(full_path); // Read the file
        }
    }
}

int main() {
    FRESULT fr;
    FATFS fs;
    FIL fil;
    int ret;
    char buf[100];
    char filename[] = "test04.txt";

    // Initialize chosen serial port
    stdio_init_all();
    sleep_ms(10000);

    // Initialize SD card
    if (!sd_init_driver()) {
        printf("ERROR: Could not initialize SD card\r\n");
        while (true);
    }

    // Mount drive
    fr = f_mount(&fs, "0:", 1);
    if (fr != FR_OK) {
        printf("ERROR: Could not mount filesystem (%d)\r\n", fr);
        while (true);
    }

    // Open file for writing ()
    fr = f_open(&fil, filename, FA_WRITE | FA_CREATE_ALWAYS);
    if (fr != FR_OK) {
        printf("ERROR: Could not open file (%d)\r\n", fr);
        while (true);
    }

    // Write something to file
    ret = f_printf(&fil, "This is another test\r\n");
    if (ret < 0) {
        printf("ERROR: Could not write to file (%d)\r\n", ret);
        f_close(&fil);
        while (true);
    }
    ret = f_printf(&fil, "of writing to an SD card.\r\n");
    if (ret < 0) {
        printf("ERROR: Could not write to file (%d)\r\n", ret);
        f_close(&fil);
        while (true);
    }

    // Close file
    fr = f_close(&fil);
    if (fr != FR_OK) {
        printf("ERROR: Could not close file (%d)\r\n", fr);
        while (true);
    }

    // Open file for reading
    fr = f_open(&fil, filename, FA_READ);
    if (fr != FR_OK) {
        printf("ERROR: Could not open file (%d)\r\n", fr);
        while (true);
    }

    // Print every line in file over serial
    printf("Reading from file '%s':\r\n", filename);
    printf("---\r\n");
    while (f_gets(buf, sizeof(buf), &fil)) {
        printf(buf);
    }
    printf("\r\n---\r\n");

    // Close file
    fr = f_close(&fil);
    if (fr != FR_OK) {
        printf("ERROR: Could not close file (%d)\r\n", fr);
        while (true);
    }

    list_and_read_files("0:"); // List and read all files in root directory

    // Unmount drive
    f_unmount("0:");

    // Loop forever doing nothing
    while (true) {
        sleep_ms(1000);
    }
}